package tests;

import base.BaseTest;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;
import pages.SeatSelectionPage;

public class BookMyShowTest extends BaseTest {

    @Test
    public void seatBookingTest() throws InterruptedException {

        driver.get("https://in.bookmyshow.com");

        // City selection (if popup)
        try {
            WebElement city = driver.findElement(
                    By.xpath("//span[contains(text(),'Bengaluru') or contains(text(),'Bangalore')]"));
            city.click();
        } catch (Exception e) {
            System.out.println("City popup not shown");
        }

        // Search movie
        WebElement search = driver.findElement(By.xpath("//input[contains(@placeholder,'Search')]"));
        search.sendKeys("Avengers");

        Thread.sleep(2000);

        driver.findElement(By.xpath("//strong[contains(text(),'Avengers')]")).click();

        driver.findElement(By.xpath("//button[contains(text(),'Book tickets')]")).click();

        driver.findElement(By.xpath("(//div[contains(@class,'showtime')])[1]")).click();

        // Seat selection page
        SeatSelectionPage seatPage = new SeatSelectionPage(driver);

        seatPage.selectTwoSeats();

        int selected = seatPage.chooseSeats(2);

        Assert.assertEquals(selected, 2);

        System.out.println("Test completed successfully");
    }
}