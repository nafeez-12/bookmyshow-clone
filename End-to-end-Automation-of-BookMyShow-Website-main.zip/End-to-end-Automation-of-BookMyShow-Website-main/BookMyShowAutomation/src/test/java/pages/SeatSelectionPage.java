package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.util.List;

public class SeatSelectionPage {

    WebDriver driver;

    public SeatSelectionPage(WebDriver driver) {
        this.driver = driver;
    }

    By twoSeats = By.xpath("//li[text()='2']");
    By selectSeatsBtn = By.xpath("//button[contains(text(),'Select Seats')]");
    By availableSeats = By.xpath("//*[name()='svg']//*[contains(@class,'available')]");

    public void selectTwoSeats() {
        driver.findElement(twoSeats).click();
        driver.findElement(selectSeatsBtn).click();
    }

    public int chooseSeats(int count) {
        List<WebElement> seats = driver.findElements(availableSeats);

        int selected = 0;
        for (WebElement seat : seats) {
            if (selected < count) {
                seat.click();
                selected++;
            }
        }
        return selected;
    }
}