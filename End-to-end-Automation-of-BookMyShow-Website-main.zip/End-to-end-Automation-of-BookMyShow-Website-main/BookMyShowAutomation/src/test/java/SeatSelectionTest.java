import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.openqa.selenium.Keys;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import io.github.bonigarcia.wdm.WebDriverManager;

import java.time.Duration;
import java.util.List;

public class SeatSelectionTest {

    WebDriver driver;
    WebDriverWait wait;

    @BeforeClass
    public void setup() {
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        wait = new WebDriverWait(driver, Duration.ofSeconds(20));
    }

    @Test
    public void bookMovieSeats() throws InterruptedException {

        driver.get("https://in.bookmyshow.com");

        try {
            WebElement bangalore = wait.until(
            	    ExpectedConditions.elementToBeClickable(By.xpath("//p[contains(text(),'Bengaluru')]"))
            		);

            		bangalore.click();
        } catch (Exception e) {
            System.out.println("City popup not displayed");
        }

        WebElement searchBar = wait.until(
        	    ExpectedConditions.elementToBeClickable(
        	        By.xpath("//span[contains(text(),'Search for Movies, Events, Plays, Sports and Activities')]")
        	    )
        	);
        	searchBar.click();

        	WebElement inputBox = wait.until(
        	    ExpectedConditions.elementToBeClickable(
        	        By.xpath("//input[contains(@placeholder,'Search')]")
        	    )
        	);

        	Actions actions = new Actions(driver);
        	actions.click(inputBox)
        	       .sendKeys("Dhurandhar")
        	       .pause(Duration.ofSeconds(2))
        	       .sendKeys(Keys.ENTER)
        	       .perform();

        Thread.sleep(2000);

        WebElement movie = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("//*[contains(text(),'Dhurandhar')]")));
        movie.click();

        WebElement bookBtn = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("//button[contains(text(),'Book tickets') or contains(text(),'Book Tickets')]")));
        bookBtn.click();

        WebElement firstShow = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("(//div[contains(@class,'showtime')])[1]")));
        firstShow.click();

        try {
            WebElement acceptBtn = wait.until(ExpectedConditions.elementToBeClickable(
                    By.xpath("//button[contains(text(),'Accept') or contains(text(),'OK')]")));
            acceptBtn.click();
        } catch (Exception e) {
            System.out.println("No popup");
        }

        WebElement twoSeats = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("//li[text()='2']")));
        twoSeats.click();

        WebElement selectSeatsBtn = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("//button[contains(text(),'Select Seats')]")));
        selectSeatsBtn.click();

        List<WebElement> seats = wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(
                By.xpath("//*[name()='svg']//*[contains(@class,'available')]")));

        int count = 0;
        for (WebElement seat : seats) {
            if (count < 2) {
                seat.click();
                count++;
                Thread.sleep(1000);
            }
        }

        Assert.assertEquals(count, 2);

        WebElement continueBtn = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("//button[contains(text(),'Pay') or contains(text(),'Continue')]")));
        Assert.assertTrue(continueBtn.isDisplayed());

        WebElement totalPrice = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath("//*[contains(text(),'Total') or contains(text(),'Amount')]")));
        Assert.assertTrue(totalPrice.isDisplayed());

        System.out.println("Seat booking automation successful");
    }
}